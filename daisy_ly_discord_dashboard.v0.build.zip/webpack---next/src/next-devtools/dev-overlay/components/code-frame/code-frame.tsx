import { useMemo } from 'react'
import { HotlinkedText } from '../hot-linked-text'
import { getStackFrameFile, type StackFrame } from '../../../shared/stack-frame'
import { useOpenInEditor } from '../../utils/use-open-in-editor'
import { FileIcon } from '../../icons/file'
import { CodeFrameShell } from './code-frame-shell'
import {
  formatCodeFrame,
  groupCodeFrameLines,
  parseLineNumberFromCodeFrameLine,
} from './parse-code-frame'

type CodeFrameProps = {
  stackFrame: StackFrame
  codeFrame: string
}

export function CodeFrame({ stackFrame, codeFrame }: CodeFrameProps) {
  const parsedLineStates = useMemo(() => {
    const decodedLines = groupCodeFrameLines(formatCodeFrame(codeFrame))

    return decodedLines.map((line) => {
      return {
        line,
        parsedLine: parseLineNumberFromCodeFrameLine(line, stackFrame),
      }
    })
  }, [codeFrame, stackFrame])

  const open = useOpenInEditor({
    file: stackFrame.file,
    line1: stackFrame.line1 ?? 1,
    column1: stackFrame.column1 ?? 1,
  })

  const fileExtension = stackFrame?.file?.split('.').pop()
  return (
    <CodeFrameShell
      header={
        <>
          <span className="code-frame-icon">
            <FileIcon lang={fileExtension} />
          </span>
          <span data-text>
            {getStackFrameFile(stackFrame)} @{' '}
            <HotlinkedText text={stackFrame.methodName} />
          </span>
        </>
      }
      onOpen={open}
    >
      {parsedLineStates.map(({ line, parsedLine }, lineIndex) => {
        const { lineNumber, isErroredLine } = parsedLine

        const lineNumberProps: Record<string, string | boolean> = {}
        if (lineNumber) {
          lineNumberProps['data-nextjs-codeframe-line'] = lineNumber
        }
        if (isErroredLine) {
          lineNumberProps['data-nextjs-codeframe-line--errored'] = true
        }

        return (
          <div key={`line-${lineIndex}`} {...lineNumberProps}>
            {line.map((entry, entryIndex) => (
              <span
                key={`frame-${entryIndex}`}
                style={{
                  color: entry.fg ? `var(--color-${entry.fg})` : undefined,
                  ...(entry.decoration === 'bold'
                    ? // TODO(jiwon): This used to be 800, but the symbols like `─┬─` are
                      // having longer width than expected on Geist Mono font-weight
                      // above 600, hence a temporary fix is to use 500 for bold.
                      { fontWeight: 500 }
                    : entry.decoration === 'italic'
                      ? { fontStyle: 'italic' }
                      : undefined),
                }}
              >
                {entry.content}
              </span>
            ))}
          </div>
        )
      })}
    </CodeFrameShell>
  )
}

export const CODE_FRAME_STYLES = `
  [data-nextjs-codeframe] {
    --code-frame-padding: 12px;
    --code-frame-line-height: var(--size-20);
    background-color: var(--color-background-200);
    color: var(--color-gray-1000);
    text-overflow: ellipsis;
    border: 1px solid var(--color-gray-400);
    border-radius: var(--rounded-xl);
    font-family: var(--font-stack-monospace);
    font-size: var(--size-13);
    line-height: var(--code-frame-line-height);
    margin: 0;
    overflow: hidden;

    svg {
      width: var(--size-16);
      height: var(--size-16);
    }
  }

  .code-frame-link,
  .code-frame-pre {
    padding: var(--code-frame-padding);
  }

  .code-frame-pre {
    background: var(--color-background-100) !important;
    border: 1px solid var(--color-gray-200);
    border-radius: var(--rounded-xl);
    border-bottom: none;
    margin-left: -1px !important;
    width: calc(100% + 2px);
    max-width: calc(100% + 2px) !important;
  }

  .code-frame-link svg {
    display: block;
    flex-shrink: 0;
  }

  [data-with-open-in-editor-link-source-file] svg {
    width: var(--size-14);
    height: var(--size-14);
  }

  .code-frame-lines {
    min-width: max-content;
  }

  .code-frame-link [data-text] {
    font-size: var(--size-12);
    text-align: left;
  }

  .code-frame-header {
    width: 100%;
    transition: background 100ms ease-out;
    border-radius: var(--rounded-lg) var(--rounded-lg) 0 0;
  }

  [data-with-open-in-editor-link-source-file] {
    display: flex;
    align-items: center;
    justify-content: center;
    width: var(--size-24);
    height: var(--size-24);
    padding: 4px;
    margin-left: auto;
    border-radius: var(--rounded-full);

    &:focus-visible {
      outline: var(--focus-ring);
      outline-offset: -2px;
    }

    &:hover {
      background: var(--color-gray-alpha-100);
    }

    &:active {
      background: var(--color-gray-alpha-200);
    }
  }

  [data-nextjs-codeframe]::selection,
  [data-nextjs-codeframe] *::selection {
    background-color: var(--color-ansi-selection);
  }

  [data-nextjs-codeframe] *:not(a) {
    color: inherit;
    background-color: transparent;
    font-family: var(--font-stack-monospace);
  }

  [data-nextjs-codeframe-line][data-nextjs-codeframe-line--errored="true"] {
    position: relative;
    isolation: isolate;

    > span { 
      position: relative;
      z-index: 1;
    }

    &::after {
      content: "";
      width: calc(100% + var(--code-frame-padding) * 2);
      height: var(--code-frame-line-height);
      left: calc(-1 * var(--code-frame-padding));
      background: var(--color-red-200);
      box-shadow: 2px 0 0 0 var(--color-red-900) inset;
      position: absolute;
    }
  }

  [data-nextjs-codeframe-line] > span:first-child {
    color: var(--color-gray-alpha-500) !important;
  }

  [data-nextjs-codeframe-line][data-nextjs-codeframe-line--errored="true"]
    > span:first-child {
    color: var(--color-gray-alpha-1000) !important;
  }


  [data-nextjs-codeframe] > * {
    margin: 0;
  }

  .code-frame-link {
    display: flex;
    align-items: center;
    gap: 6px;
    margin: 0;
    outline: 0;
    padding-top: 8px;
    padding-bottom: 8px;
    padding-right: 8px;
  }
  .code-frame-pre {
    overflow-x: auto;
    overflow-y: hidden;
    display: block;
    max-width: 100%;
  }

  [data-nextjs-codeframe] svg {
    color: var(--color-gray-900);
  }
`
