import { DialogBody } from '../../dialog'

type ErrorOverlayDialogBodyProps = {
  children?: React.ReactNode
  onClose?: () => void
}

export function ErrorOverlayDialogBody({
  children,
}: ErrorOverlayDialogBodyProps) {
  return (
    <DialogBody className="nextjs-container-errors-body">{children}</DialogBody>
  )
}

export const DIALOG_BODY_STYLES = `
  [data-nextjs-dialog-body] {
    padding-left: 20px;
    padding-right: 20px;
    padding-bottom: 20px;
  }
`
