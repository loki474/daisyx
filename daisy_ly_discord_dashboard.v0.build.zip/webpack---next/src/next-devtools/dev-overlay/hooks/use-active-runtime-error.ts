import type { ReadyRuntimeError } from '../utils/get-error-by-type'
import type { HydrationErrorState } from '../../shared/hydration-error'

import { useMemo, useState } from 'react'
import { getErrorTypeLabel, useErrorDetails } from '../container/errors'

export function useActiveRuntimeError({
  runtimeErrors,
  getSquashedHydrationErrorDetails,
  activeIdx: controlledActiveIdx,
  setActiveIndex: controlledSetActiveIndex,
}: {
  runtimeErrors: ReadyRuntimeError[]
  getSquashedHydrationErrorDetails: (error: Error) => HydrationErrorState | null
  activeIdx?: number
  setActiveIndex?: (index: number) => void
}) {
  const [uncontrolledActiveIdx, setUncontrolledActiveIndex] =
    useState<number>(0)
  const activeIdx = controlledActiveIdx ?? uncontrolledActiveIdx
  const setActiveIndex = controlledSetActiveIndex ?? setUncontrolledActiveIndex

  const isLoading = useMemo<boolean>(() => {
    return runtimeErrors.length === 0
  }, [runtimeErrors.length])

  const activeError = useMemo<ReadyRuntimeError | null>(
    () => runtimeErrors[activeIdx] ?? null,
    [activeIdx, runtimeErrors]
  )

  const errorDetails = useErrorDetails(
    activeError?.error,
    getSquashedHydrationErrorDetails
  )

  if (isLoading || !activeError) {
    return {
      isLoading,
      activeIdx,
      setActiveIndex,
      activeError: null,
      errorDetails: null,
      errorType: null,
    }
  }

  const error = activeError.error
  const errorType = getErrorTypeLabel(error, activeError.type, errorDetails)

  return {
    isLoading,
    activeIdx,
    setActiveIndex,
    activeError,
    errorDetails,
    errorType,
  }
}
