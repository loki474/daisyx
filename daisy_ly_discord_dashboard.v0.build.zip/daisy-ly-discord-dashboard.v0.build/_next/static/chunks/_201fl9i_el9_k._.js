(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/node_modules__pnpm_1dl_4wlvggg_y._.js", "static/chunks/app_globals_0yg4wg8plh8sv.css", "static/chunks/_0ybs4wp8_4xjy._.js", "static/chunks/node_modules__pnpm_0t2gi0buou1s9._.js"],
    source: "entry"
});