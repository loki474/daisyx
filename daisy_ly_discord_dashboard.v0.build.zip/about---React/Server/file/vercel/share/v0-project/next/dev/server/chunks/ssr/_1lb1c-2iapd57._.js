/* This module was rendered by a Server Component. Turn on Source Maps to see the server source. */






























































({
    "RootLayout": _ =>
        _()
})
//# sourceURL=about://React/Server/file:///vercel/share/v0-project/.next/dev/server/chunks/ssr/_1lb1c-2iapd57._.js?0
//# sourceMappingURL=https://daisy-ly-discord-dashboard.v0.build/__nextjs_source-map?filename=%2Fvercel%2Fshare%2Fv0-project%2F.next%2Fdev%2Fserver%2Fchunks%2Fssr%2F_1lb1c-2iapd57._.js